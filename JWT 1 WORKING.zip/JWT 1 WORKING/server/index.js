const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const UserModel = require('./model/UserModel');

//Authentication
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
//----------------------------------------

const app = express();

// middleware

//auth
app.use(cors({
    origin: ['http://localhost:5173'],
    methods: ['GET', 'POST'],
    credentials: true
}));


//_________________
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(cookieParser());

// mongoDB connection

mongoose.connect("mongodb://localhost:27017/JWT-APP-1")
const db=mongoose.connection;
db.on('error',console.error.bind(console,"conection error"));
db.once('open',function(){
    console.log(" Mongo DB Connected sucessfully")
});





//Verify User(middleware)

const VerifyUser = (req, res, next) =>{
    const token = req.cookies.token;
    // console.log(token);

    if(!token){
        return res.json("The token was not Available");
    }else{
        jwt.verify(token,"jwt-secret-key", (err,decoded) =>{
            if(err) {
                return res.json("Token is wrong");
            }else{
                // return res.json(decoded);
                next();
            }

            
        })
    }


}

//Register User
app.post('/register',(req,res) => {
    const {name,email,password} = req.body;

    bcrypt.hash(password, 10)

    .then(hash => {
         UserModel.create({name,email, password: hash})
        .then(result => res.json(result))
        .catch(err => res.json(err))
    }).catch(err => console.log(err))


})



//Home 

app.get('/details', VerifyUser, async (req, res) =>{
    try{
        await UserModel.find()
        .then(result => res.json(result))
        
        .catch(err => res.json(err))

    }catch(err){
        console.log(err)
    }
    
})

//Login User

app.post('/login',(req,res) => {
    const {email,password} = req.body;
    try {
        UserModel.findOne({email: email})

        .then((user)=>{
            if(user) {

                   //password compare

                bcrypt.compare(password,user.password, (err,response) => {
                    if(err) {
                        console.log ("Compare error"+err);
                    }
                    // console.log(err)
                    if(response){

                        //generate token
                        const token = jwt.sign({email: user.email}, "jwt-secret-key", {expiresIn:60})
                        res.cookie('token',token);
                        res.json("success");
                        
                    }else{
                        res.json("Password is incorrect");
                    }
                })

            }else {
                res.json("No records found");
            }
        })
        
    } catch(err){
        console.log("Login err is " + err)
    }
})

app.listen(3001,() => 
console.log("port is running port = 3001")
);