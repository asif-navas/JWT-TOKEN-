import React, { useEffect, useState } from 'react'
import axios from 'axios'
import './details.css';
import { useNavigate } from 'react-router-dom';

function Details() {

    const [details, setDetails] = useState([]);
    const navigate = useNavigate();


    axios.defaults.withCredentials = true;
    useEffect(() => {
        axios.get('http://localhost:3001/details')
            .then(result => {
                console.log(result);
                if (result.data === "The token was not Available" || result.data === "Token is wrong") {
                    alert(result.data);
                } else {
                    setDetails(result.data);
                }
            })
            .catch(err => console.log(err));
    }, []);
    
    

  return (
    <div className='deta'>
        {
            details.map((details,index)=>{
                return (
                    <div className='de' key={index}>

                        <p> Name : {details.name}</p>
                        <p> Email : {details.email}</p>
                        
                        
                    </div>
                )
            })
        }
    </div>
  )
}

export default Details


