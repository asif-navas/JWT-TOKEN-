import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import './Home.css';
import axios from 'axios';

function Home() {
  // axios.defaults.withCredentials = true;
  // useEffect(() =>{
  //   axios.get('http://localhost:3001/details')
  //     .then(result =>{
  //       console.log (result);

  //       if(result.data !== 'success'){

  //         navigate('/login')

  //       }

  //     } )

  // },[])

  return (
    <div className='hme'>
        <Link className='hsing' to="/signUp">SignUp</Link>
        <Link className='hlog' to="/login">Login</Link>
        <Link className='hsing' to="/details">Details</Link>

        
    </div>
  )
}

export default Home