import React, { useState } from 'react';
import './SignUp.css';
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios';

function SignUp() {

  const [name,setName] = useState('');
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');

  const navigate = useNavigate();



  const handleSignUp = async (event) => {
    event.preventDefault();
    try {
      const response = await axios.post('http://localhost:3001/register', { name, email, password });
      console.log(response);
      // Assuming navigate is a function that performs navigation
      navigate('/login');
    } catch (err) {
      console.log("Error: ", err);
    }
  };
  

  return (
    <div >
      <h2>User Registration</h2>

      <form onSubmit={handleSignUp}>
        {/* Name */}
        <label htmlFor="name">Name:</label>
        <input type="text" id="name" name="name" placeholder='Enter Name' onChange={(e) => setName(e.target.value)} required />

        {/* Email */}
        <label htmlFor="email">Email:</label>
        <input type="email" id="email" name="email" placeholder='Enter Email' onChange={(e) => setEmail(e.target.value)} required />

        {/* Password */}
        <label htmlFor="password">Password:</label>
        <input type="password" id="password" name="password" placeholder='Enter Password' onChange={(e) => setPassword (e.target.value)} required />

        <Link  to="/login">Alredy Have an account ?</Link>

        {/* Submit Button */}
        <input type="submit" value="SignUp" />
      </form>
    </div>
  );
}

export default SignUp;
